package com.sheunglaili.binder.mqtt.config;


import com.sheunglaili.binder.mqtt.MqttMessageChannelBinder;
import com.sheunglaili.binder.mqtt.MqttProvisioningProvider;
import com.sheunglaili.binder.mqtt.properties.MqttBinderConfigurationProperties;
import com.sheunglaili.binder.mqtt.properties.MqttBindingProperties;
import com.sheunglaili.binder.mqtt.properties.MqttExtendedBindingProperties;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.stream.binder.Binder;
import org.springframework.cloud.stream.binder.BinderFactory;
import org.springframework.cloud.stream.config.BindingHandlerAdvise;
import org.springframework.cloud.stream.config.BindingProperties;
import org.springframework.cloud.stream.config.BindingServiceProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.util.ObjectUtils;

/**
 * Mqtt binder configuration class
 * @author Alex , Li Sheung Lai
 */
@Configuration
@EnableConfigurationProperties({
        MqttExtendedBindingProperties.class})
public class MqttBinderConfiguration {

    @Autowired
    private MqttExtendedBindingProperties mqttExtendedBindingProperties;




    @Bean
    public MqttBinderConfigurationProperties configurationProperties(){
        return new MqttBinderConfigurationProperties();
    }

    @Bean
    public MqttProvisioningProvider provisioningProvider(MqttBinderConfigurationProperties configurationProperties){
        return new MqttProvisioningProvider();
    }

    @Bean
    public MqttPahoClientFactory mqttPahoClientFactory(MqttBinderConfigurationProperties configurationProperties) {

        MqttConnectOptions options = new MqttConnectOptions();
        options.setServerURIs(configurationProperties.getUrl());
        options.setUserName(configurationProperties.getUsername());
        options.setPassword(configurationProperties.getPassword().toCharArray());
        options.setCleanSession(configurationProperties.isCleanSession());
        options.setConnectionTimeout(configurationProperties.getConnectionTimeout());
        options.setKeepAliveInterval(configurationProperties.getKeepAliveInterval());
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        factory.setConnectionOptions(options);
        if (ObjectUtils.nullSafeEquals(configurationProperties.getPersistence(), "file")) {
            factory.setPersistence(new MqttDefaultFilePersistence(configurationProperties.getPersistenceDirectory()));
        }
        else if (ObjectUtils.nullSafeEquals(configurationProperties.getPersistence(), "memory")) {
            factory.setPersistence(new MemoryPersistence());
        }
        return factory;
    }

    @Bean
    public MqttMessageChannelBinder mqttMessageChannelBinder(MqttPahoClientFactory mqttPahoClientFactory,
                                                             MqttProvisioningProvider provisioningProvider){

       MqttMessageChannelBinder mqttMessageChannelBinder = new MqttMessageChannelBinder(mqttPahoClientFactory,provisioningProvider);
        return mqttMessageChannelBinder;
    }


}
