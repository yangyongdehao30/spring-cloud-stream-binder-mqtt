package com.sheunglaili.binder.mqtt.properties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.stream.binder.BinderSpecificPropertiesProvider;
import org.springframework.cloud.stream.config.BinderProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Size;

/**
 * Configuration properties for the Mqtt binder . The properties in the class
 * are prefixed with <b>spring.cloud.stream.mqtt.binder</b>
 * @author Alex , Li Sheung Lai
 */
@Data
@Validated
@ConfigurationProperties(prefix = "spring.cloud.stream.mqtt")
public class MqttBinderConfigurationProperties {


    /**
     * location of the mqtt broker(s) (comma-delimited list)
     */
    @Size(min = 1)
    private String[] url = new String[] { "tcp://localhost:1883" };

    /**
     * the username to use when connecting to the broker
     */
    private String username = "guest";

    /**
     * the password to use when connecting to the broker
     */
    private String password = "guest";

    /**
     * whether the client and server should remember state across restarts and reconnects
     */
    private boolean cleanSession = true;

    /**
     * the connection timeout in seconds
     */
    private int connectionTimeout = 30;

    /**
     * the ping interval in seconds
     */
    private int keepAliveInterval = 60;

    /**
     * 'memory' or 'file'
     */
    private String persistence = "memory";

    /**
     * Persistence directory
     */
    private String persistenceDirectory = "/tmp/paho";

    public MqttBinderConfigurationProperties() {
    }


    public String[] getUrl() {
        return url;
    }

    public void setUrl(String[] url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isCleanSession() {
        return cleanSession;
    }

    public void setCleanSession(boolean cleanSession) {
        this.cleanSession = cleanSession;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getKeepAliveInterval() {
        return keepAliveInterval;
    }

    public void setKeepAliveInterval(int keepAliveInterval) {
        this.keepAliveInterval = keepAliveInterval;
    }

    public String getPersistence() {
        return persistence;
    }

    public void setPersistence(String persistence) {
        this.persistence = persistence;
    }

    public String getPersistenceDirectory() {
        return persistenceDirectory;
    }

    public void setPersistenceDirectory(String persistenceDirectory) {
        this.persistenceDirectory = persistenceDirectory;
    }

}
