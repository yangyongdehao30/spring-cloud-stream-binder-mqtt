package com.sheunglaili.binder.mqtt.properties;

import lombok.Data;
import org.hibernate.validator.constraints.Range;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Validated
//@ConfigurationProperties("mqtt.sink")
public class MqttSinkProperties {

    /**
     * identifies the client
     */
    @NotBlank
    @Size(min = 1 , max = 23)
    private String clientId = "stream.client.id";

    /**
     * the topic to which the sink will publish
     */
    @NotBlank
    private String topic = "stream.mqtt";

    /**
     *  the quality of service to use
     */
    @Range(min = 0 , max = 2)
    private int qos = 1;

    /**
     * whether to set the 'retained' flag
     */
    private boolean retained = false;

    /**
     * the charset used to convert a string payload
     */
    private String charset = "UTF-8";

    /**
     * whether or not to use async sends
     */
    private  boolean async = false;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getQos() {
        return qos;
    }

    public void setQos(int qos) {
        this.qos = qos;
    }

    public boolean isRetained() {
        return retained;
    }

    public void setRetained(boolean retained) {
        this.retained = retained;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public boolean isAsync() {
        return async;
    }

    public void setAsync(boolean async) {
        this.async = async;
    }
}
